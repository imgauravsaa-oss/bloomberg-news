import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'services/news_provider.dart';
import 'screens/home_screen.dart';
import 'theme/terminal_theme.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.light,
    systemNavigationBarColor: TerminalTheme.bgCard,
    systemNavigationBarIconBrightness: Brightness.light,
  ));
  runApp(const BloombergNewsApp());
}

class BloombergNewsApp extends StatelessWidget {
  const BloombergNewsApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => NewsProvider()..startAutoRefresh(),
      child: MaterialApp(
        title: 'Claude Terminal',
        debugShowCheckedModeBanner: false,
        theme: TerminalTheme.theme,
        home: const HomeScreen(),
      ),
    );
  }
}
