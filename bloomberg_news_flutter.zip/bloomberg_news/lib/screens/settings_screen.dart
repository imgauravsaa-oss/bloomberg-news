import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/news_provider.dart';
import '../theme/terminal_theme.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<NewsProvider>();
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const _SectionHeader('REFRESH SETTINGS'),
        const SizedBox(height: 8),
        _SettingRow(
          label: 'AUTO-REFRESH INTERVAL',
          value: '${provider.refreshInterval} MIN',
          child: Slider(
            value: provider.refreshInterval.toDouble(),
            min: 1,
            max: 30,
            divisions: 29,
            activeColor: TerminalTheme.amber,
            inactiveColor: TerminalTheme.border,
            onChanged: (v) => provider.setRefreshInterval(v.round()),
          ),
        ),
        const SizedBox(height: 24),
        const _SectionHeader('DATA'),
        const SizedBox(height: 8),
        _InfoRow(label: 'TOTAL STORIES LOADED', value: '${provider.articles.length}'),
        _InfoRow(label: 'BREAKING STORIES', value: '${provider.breaking.length}'),
        _InfoRow(
          label: 'LAST UPDATE',
          value: provider.lastUpdated != null
              ? '${provider.lastUpdated!.hour.toString().padLeft(2, '0')}:${provider.lastUpdated!.minute.toString().padLeft(2, '0')}'
              : '--:--',
        ),
        const SizedBox(height: 24),
        const _SectionHeader('ABOUT'),
        const SizedBox(height: 8),
        const _InfoRow(label: 'POWERED BY', value: 'CLAUDE AI'),
        const _InfoRow(label: 'MODEL', value: 'CLAUDE SONNET 4'),
        const _InfoRow(label: 'DATA SOURCE', value: 'LIVE WEB SEARCH'),
        const SizedBox(height: 24),
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            border: Border.all(color: TerminalTheme.border),
            color: TerminalTheme.bgCard,
          ),
          child: const Text(
            'This app uses the Anthropic Claude API with web search to fetch real-time world news. Add your API key in lib/services/news_service.dart.',
            style: TextStyle(
              fontSize: 10,
              color: TerminalTheme.textDim,
              fontFamily: 'monospace',
              height: 1.6,
            ),
          ),
        ),
      ],
    );
  }
}

class _SectionHeader extends StatelessWidget {
  final String text;
  const _SectionHeader(this.text);

  @override
  Widget build(BuildContext context) {
    return Text(
      text,
      style: const TextStyle(
        fontSize: 9,
        color: TerminalTheme.amber,
        fontFamily: 'monospace',
        fontWeight: FontWeight.w700,
        letterSpacing: 1.2,
      ),
    );
  }
}

class _SettingRow extends StatelessWidget {
  final String label;
  final String value;
  final Widget child;

  const _SettingRow({required this.label, required this.value, required this.child});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: const BoxDecoration(
        border: Border(bottom: BorderSide(color: TerminalTheme.border)),
        color: TerminalTheme.bgCard,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(label, style: const TextStyle(fontSize: 10, color: TerminalTheme.textSecondary, fontFamily: 'monospace')),
              Text(value, style: const TextStyle(fontSize: 10, color: TerminalTheme.amber, fontFamily: 'monospace', fontWeight: FontWeight.w700)),
            ],
          ),
          child,
        ],
      ),
    );
  }
}

class _InfoRow extends StatelessWidget {
  final String label;
  final String value;
  const _InfoRow({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: const BoxDecoration(
        border: Border(bottom: BorderSide(color: TerminalTheme.border)),
        color: TerminalTheme.bgCard,
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: const TextStyle(fontSize: 10, color: TerminalTheme.textMuted, fontFamily: 'monospace')),
          Text(value, style: const TextStyle(fontSize: 10, color: TerminalTheme.textSecondary, fontFamily: 'monospace', fontWeight: FontWeight.w600)),
        ],
      ),
    );
  }
}
